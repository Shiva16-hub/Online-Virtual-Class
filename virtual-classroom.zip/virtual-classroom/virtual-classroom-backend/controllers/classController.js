const Class = require('../models/Class');
const User = require('../models/User');

exports.createClass = async (req, res) => {
    const { title, description } = req.body;
    const instructor = req.user.id;

    const newClass = new Class({ title, description, instructor });
    await newClass.save();
    res.status(201).json(newClass);
};

exports.getAllClasses = async (req, res) => {
    const classes = await Class.find().populate('instructor', 'name');
    res.json(classes);
};
