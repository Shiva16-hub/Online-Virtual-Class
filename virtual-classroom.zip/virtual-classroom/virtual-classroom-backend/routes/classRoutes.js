const express = require('express');
const { createClass, getAllClasses } = require('../controllers/classController');
const { isAuthenticated, isInstructor } = require('../middleware/authMiddleware');

const router = express.Router();

router.post('/', isAuthenticated, isInstructor, createClass);
router.get('/', getAllClasses);

module.exports = router;
