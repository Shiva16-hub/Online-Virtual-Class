import React from 'react';
import { Card, CardContent, Typography, Button } from '@mui/material';
import { Link } from 'react-router-dom';

const ClassCard = ({ classData }) => (
  <Card>
    <CardContent>
      <Typography variant="h5" gutterBottom>
        {classData.title}
      </Typography>
      <Typography variant="body2" color="textSecondary">
        Instructor: {classData.instructor.name}
      </Typography>
      <Typography variant="body1" gutterBottom>
        {classData.description}
      </Typography>
      <Button variant="contained" color="primary" component={Link} to={`/lecture/${classData._id}`}>
        View Lectures
      </Button>
    </CardContent>
  </Card>
);

export default ClassCard;
