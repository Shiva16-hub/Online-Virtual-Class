import React from 'react';
import { Card, CardContent, Typography, TextField, Button } from '@mui/material';

const Comment = ({ commentData }) => (
  <Card style={{ marginBottom: '1rem' }}>
    <CardContent>
      <Typography variant="body1">{commentData.content}</Typography>
      <Typography variant="body2" color="textSecondary">
        - {commentData.user.name}
      </Typography>
      {commentData.replies && commentData.replies.map(reply => (
        <Comment key={reply._id} commentData={reply} />
      ))}
    </CardContent>
  </Card>
);

export default Comment;
