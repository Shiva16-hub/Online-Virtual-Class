import React from 'react';
import { Card, CardContent, Typography, Button } from '@mui/material';

const LectureCard = ({ lecture }) => (
  <Card>
    <CardContent>
      <Typography variant="h5" gutterBottom>
        {lecture.title}
      </Typography>
      <Typography variant="body2" color="textSecondary">
        Session: {lecture.sessionId}
      </Typography>
      <Typography variant="body1" gutterBottom>
        {lecture.content}
      </Typography>
      <Button variant="contained" color="secondary">
        Join Discussion
      </Button>
    </CardContent>
  </Card>
);

export default LectureCard;
