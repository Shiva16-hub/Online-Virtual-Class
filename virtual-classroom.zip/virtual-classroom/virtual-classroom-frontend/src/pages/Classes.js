import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Container, Typography, Grid } from '@mui/material';
import ClassCard from '../components/ClassCard';

const Classes = () => {
  const [classes, setClasses] = useState([]);

  useEffect(() => {
    axios.get('/api/classes')
      .then(response => setClasses(response.data))
      .catch(err => console.error(err));
  }, []);

  return (
    <Container>
      <Typography variant="h4" gutterBottom>
        Available Classes
      </Typography>
      <Grid container spacing={3}>
        {classes.map(cls => (
          <Grid item xs={12} sm={6} md={4} key={cls._id}>
            <ClassCard classData={cls} />
          </Grid>
        ))}
      </Grid>
    </Container>
  );
};

export default Classes;
