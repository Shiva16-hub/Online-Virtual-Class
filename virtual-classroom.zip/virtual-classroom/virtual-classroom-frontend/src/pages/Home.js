import React from 'react';
import { Container, Typography } from '@mui/material';

const Home = () => (
  <Container>
    <Typography variant="h3" gutterBottom>
      Welcome to the Virtual Classroom
    </Typography>
    <Typography variant="body1">
      Access your classes, view lectures, and participate in discussions with fellow students.
    </Typography>
  </Container>
);

export default Home;
