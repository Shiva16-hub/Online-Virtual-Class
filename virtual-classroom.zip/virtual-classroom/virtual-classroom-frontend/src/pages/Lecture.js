import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import { Container, Typography, Grid } from '@mui/material';
import LectureCard from '../components/LectureCard';

const Lecture = () => {
  const { id } = useParams();
  const [lectures, setLectures] = useState([]);

  useEffect(() => {
    axios.get(`/api/lectures/${id}`)
      .then(response => setLectures(response.data))
      .catch(err => console.error(err));
  }, [id]);

  return (
    <Container>
      <Typography variant="h4" gutterBottom>
        Lectures
      </Typography>
      <Grid container spacing={3}>
        {lectures.map(lecture => (
          <Grid item xs={12} sm={6} md={4} key={lecture._id}>
            <LectureCard lecture={lecture} />
          </Grid>
        ))}
      </Grid>
    </Container>
  );
};

export default Lecture;
